# CCEXTRAP (PHP)
Script otomatis membuat beberapa Credit Card sesuai jumlah yang kita minta.<br>
Script ini juga otomatis check Live | Die | Unknow. <br>

# Install
- apt update && apt upgrade 
- apt install php curl git
- git clone https://github.com/kyo1337/CCEXTRAP
- cd CCEXTRAP
- php run.php

# Petunjuk Pengguna
- Bin : {Input Bin Seterah Kalian}
- Check Status Valid : {Input salah satu angka, 1 or 0}<br>
  ~ Angka 1 : Auto Check Status Live Or Die Or Unknow CC Generate<br>
  ~ Angka 2 : Manual Check Status Live Or Die Or Unknow Via Website
- Amount/Jumlah : {Input Bebas Jumlah Seterah Kalian}

# Note
- https://linktr.ee/doko1554

# ScreenShot
![Capture](https://user-images.githubusercontent.com/33697576/79683548-1dae1380-8255-11ea-84c2-09baa34677d2.PNG)